﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace BookingService.Model
{
    public class BookingRepository : IBookingRepository
    {
        private readonly BookingContext _context = new BookingContext(options);
        //private readonly BookingContext _context// = new BookingContext(options);
        private static readonly DbContextOptions options;

        public BookingRepository(BookingContext context)
        {
            _context = context;
        }

        #region IBookingRepository Interface Implementation

        public IEnumerable<BookingInfo> GetAllBooking()
        {
            return _context.Bookings.ToList();
        }
       
        public int AddBooking(BookingInfo employeeEntity)

        {
            int result = -1;

            if (employeeEntity != null)
            {
                _context.Bookings.Add(employeeEntity);
                _context.SaveChanges();
                result = employeeEntity.BookingId;
            }
            return result;

        }
        public int UpdateBooking(BookingInfo employeeEntity)
        {
            int result = -1;

            if (employeeEntity != null)
            {
                _context.Entry(employeeEntity).State = EntityState.Modified;
                _context.SaveChanges();
                result = employeeEntity.BookingId;
            }
            return result;
        }

        #endregion

        #region IDisposable Interface Implementation

        private bool disposed = false;
        private bool disposing = false;

        public void Dispose()
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    _context.Dispose();
                }
            }
            this.disposed = true;
        }

        public BookingInfo GetBookingById(int bookingId)
        {
            return _context.Bookings.Find(bookingId);
        }

        public void DeleteBooking(int bookingId)
        {
            BookingInfo employeeEntity = _context.Bookings.Find(bookingId);
            _context.Bookings.Remove(employeeEntity);
            _context.SaveChanges();
        }

        #endregion
    }
}
