﻿using System;
using System.Collections.Generic;

namespace BookingService.Model
{
    public interface IBookingRepository : IDisposable   
    {
        IEnumerable<BookingInfo> GetAllBooking();
        BookingInfo GetBookingById(int bookingId);
        int AddBooking(BookingInfo bookingEntity);
        int UpdateBooking(BookingInfo bookingEntity);
        void DeleteBooking(int bookingId);
    }
}
